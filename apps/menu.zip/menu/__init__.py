default_app_config = 'apps.menu.apps.MenuConfig'
